
var img1;
var img2;


function preload(){
  img = loadImage("forest.jpg");
  img2 = loadImage("bird.png");
}


function setup() {
  createCanvas(900, 500);
  textFont("Calibri");
}

function draw() {
  background(220);
  image(img, 0, 0);
  textSize(70);
  text("Bird?", 650,50,10,500);

textSize(30);
  textFont("Della Respira");
  stroke(255);
  strokeWeight(10);
  colorMode(RGB);
  fill(255,0,0);
  text("Kaw kaw!", mouseX, mouseY-100);


  image(img2, mouseX-100, mouseY-100);
}