function setup() {
  createCanvas(500, 500);
  rand = random(0.1,1);
  frameRate(1); //changes every one second
  //noLoop();
}

function draw() {
  background(220);
  line(0,300,500,300);
  angleMode(DEGREES);
  for(var x = 0; x < 500; x+=49){ //make many flakes
    rotate(random(0,1));
    flake(x,100+(random(-100,200)));
  }
}


function flake(x,y){ // It's snowing!
  push();
  translate(x,y);
  var rand = random(0.1,0.5)
  scale(rand);
  stroke(0);
  strokeWeight(5);
  for(var i = 0; i < 8; i++){ //create a flake by making one arm and looping + rotating to create the whole flake
    line(0,0,0,50);
    line(0,25,-20,50);
    line(0,25,20,50);
    ellipse(0,0,10);
    rotate(45);
  }
  pop();
  print("Flake at: ("+x+ ", "+ y+ "), scale: " + rand + ". "); //flake is given random scale and each creation
}