let yPos = 0;
let i = 50;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  frameRate(30);
  for(i = 50; i < 400; i=i+50){
    ellipse(i, 200, 10);
  }
  if(mouseIsPressed){
    yPos = mouseY;
    for(i = 25; i < 400; i=i+25){
    ellipse(i, yPos, 10);
    }
  }
  if(keyIsPressed){
    colorMode(RGB);
    fill(mouseX,mouseY,i);
  }
}